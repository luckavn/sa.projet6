package com.axa.softwareacademy.p6.constant;

public class commission {
    public static final double fourPourcentCommission = 0.04;
    public static final double fivePourcentCommission = 0.05;
    public static final double sixPourcentCommission = 0.06;
}
