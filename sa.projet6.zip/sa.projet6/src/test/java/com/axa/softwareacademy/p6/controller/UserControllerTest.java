package com.axa.softwareacademy.p6.controller;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@EnableAutoConfiguration
@AutoConfigureMockMvc
@AutoConfigureTestDatabase
@ExtendWith(MockitoExtension.class)
public class UserControllerTest {

    @Autowired
    MockMvc mockmvc;

    @Test
    @Sql(scripts = "classpath:data-h2.sql")
    public void getAllUsers() throws Exception {
        this.mockmvc.perform(get("/user/all"))
                .andExpect(status().isOk())
                .andDo(MockMvcResultHandlers.print());
    }

    @Test
    public void addNewUser() throws Exception {
        this.mockmvc.perform(post("/user/addUser")
                .param("firstname", "John")
                .param("lastname", "Doe")
                .param("email", "john.doe@gmail.com"))
                .andExpect(status().isOk())
                .andDo(MockMvcResultHandlers.print());
    }

    @Test
    @Sql(scripts = "classpath:data-h2.sql")
    public void addFriendsListToUser() throws Exception {
        this.mockmvc.perform(post("/user/addFriend")
                .param("userId", "1")
                .param("friendEmail", "lv@gmail.com"))
                .andExpect(status().isOk())
                .andDo(MockMvcResultHandlers.print());
    }
//    public void addCreditCardToUser() {}
//    public void addRefillToUserBalance() {}
//    public void createPaymentAndUpdateBalances() {}
//    public void createBankAccountAndLinkToUser() {}
//    public void createTransferAndUpdateUserAccount() {}
}
