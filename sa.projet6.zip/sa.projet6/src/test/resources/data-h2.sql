insert into USER(id, first_name, last_name, email) values(1, 'John', 'Boyd','jb@gmail.com');
insert into USER(id, first_name, last_name, email) values(2, 'Lucas', 'Vannier','lv@gmail.com');

