INSERT INTO ACCOUNT(id, balance, currency) values(1, 500, 'euro');
INSERT INTO ACCOUNT(id, balance, currency) values(2, 500, 'euro');
INSERT INTO USER(id, first_name, last_name, email, password, account_id) values(1, 'John', 'Doe', 'john.doe@gmail.com', 'password', 1);
INSERT INTO USER(id, first_name, last_name, email, password, account_id) values(2, 'Marc', 'Doe', 'marc.doe@gmail.com', 'password', 2);
